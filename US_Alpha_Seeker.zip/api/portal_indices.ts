export default async function handler(req: any, res: any) {
  // Portal Proxy v4: "Ironclad" Strategy with RapidAPI Integration
  // Priority: 1. CNBC Direct (Speed) -> 2. RapidAPI CNBC (Stability/Proxy) -> 3. TradingView (Backup) -> 4. Investing (Last Resort)
  
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  const parseValue = (str: string | number) => {
    if (typeof str === 'number') return str;
    return parseFloat(String(str).replace(/,/g, '').replace(/%/g, ''));
  };

  // --- STRATEGY A: CNBC DIRECT (Fastest, No Quota) ---
  const fetchCNBC = async () => {
    try {
        const symbols = ".IXIC|.SPX|.DJI|.VIX|AAPL|NVDA|TSLA|MSFT";
        const url = `https://quote.cnbc.com/quote-html-webservice/quote.htm?partnerId=2&requestMethod=quick&exthrs=1&noform=1&fund=1&output=json&players=null&symbols=${symbols}`;
        
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        if (!response.ok) throw new Error(`CNBC Direct Status ${response.status}`);
        const data = await response.json();
        const quotes = data.QuickQuoteResult?.QuickQuote;
        if (!quotes || !Array.isArray(quotes)) throw new Error("CNBC Direct Empty");

        return normalizeQuotes(quotes, 'CNBC_Direct');
    } catch (e) {
        console.error("Strategy A (Direct) Fail:", e);
        return null;
    }
  };

  // --- STRATEGY B: RAPID API CNBC (Reliable Proxy - NEW) ---
  const fetchRapidCNBC = async () => {
    try {
        const RAPID_KEY = '9732bdf9b4msh26c34f61e9a7fc4p1eca3ajsncd56ae81b71e';
        const RAPID_HOST = 'cnbc.p.rapidapi.com';
        const symbols = ".IXIC|.SPX|.DJI|.VIX|AAPL|NVDA|TSLA|MSFT";
        
        // This endpoint mimics the official CNBC structure via RapidAPI proxy
        const url = `https://${RAPID_HOST}/market/get-quote?symbol=${encodeURIComponent(symbols)}&requestMethod=quick&exthrs=1&noform=1&fund=1&output=json`;

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': RAPID_KEY,
                'X-RapidAPI-Host': RAPID_HOST
            }
        });

        if (!response.ok) throw new Error(`RapidAPI Status ${response.status}`);
        
        const data = await response.json();
        // RapidAPI usually wraps the same structure
        const quotes = data.QuickQuoteResult?.QuickQuote;
        
        if (!quotes || !Array.isArray(quotes)) throw new Error("RapidAPI Empty Data");

        return normalizeQuotes(quotes, 'CNBC_RapidAPI');

    } catch (e) {
        console.error("Strategy B (RapidAPI) Fail:", e);
        return null;
    }
  };

  // Helper to normalize CNBC-style responses (used by Strategy A & B)
  const normalizeQuotes = (quotes: any[], sourceLabel: string) => {
    const map: Record<string, string> = {
        ".IXIC": "NASDAQ",
        ".SPX": "SP500",
        ".DJI": "DOW",
        ".VIX": "VIX",
        "AAPL": "AAPL",
        "NVDA": "NVDA",
        "TSLA": "TSLA",
        "MSFT": "MSFT"
    };

    const results = quotes.map((q: any) => {
        const internalSymbol = map[q.symbol] || q.symbol;
        return {
            symbol: internalSymbol,
            price: parseValue(q.last),
            change: parseValue(q.change_pct),
            source: sourceLabel
        };
    }).filter(item => item !== null);

    if (results.length < 2) throw new Error("Insufficient Data Parsed");
    return results;
  };

  // --- STRATEGY C: TRADINGVIEW SCANNER (Backup) ---
  const fetchTradingView = async () => {
    try {
      const response = await fetch('https://scanner.tradingview.com/america/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbols: {
            tickers: [
                "TVC:NDX", "TVC:SPX", "TVC:DJI", "TVC:VIX",
                "NASDAQ:AAPL", "NASDAQ:NVDA", "NASDAQ:TSLA", "NASDAQ:MSFT"
            ]
          },
          columns: ["close", "change|1"] 
        })
      });

      if (!response.ok) throw new Error(`TV Status ${response.status}`);
      const json = await response.json();
      
      if (!json.data || json.data.length === 0) throw new Error("TV Empty Data");

      const map: Record<string, string> = {
        "TVC:NDX": "NASDAQ",
        "TVC:SPX": "SP500",
        "TVC:DJI": "DOW",
        "TVC:VIX": "VIX",
        "NASDAQ:AAPL": "AAPL",
        "NASDAQ:NVDA": "NVDA",
        "NASDAQ:TSLA": "TSLA",
        "NASDAQ:MSFT": "MSFT"
      };

      return json.data.map((item: any) => ({
           symbol: map[item.s] || item.s.split(':')[1] || item.s, 
           price: item.d[0],
           change: item.d[1],
           source: 'TradingView'
      }));
    } catch (e) {
      console.error("Strategy C (TV) Fail:", e);
      return null;
    }
  };

  // --- STRATEGY D: INVESTING.COM SCRAPER (Deep Backup) ---
  const fetchInvestingCom = async () => {
    try {
      const response = await fetch('https://www.investing.com/indices/major-indices', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      if (!response.ok) throw new Error(`Investing Status ${response.status}`);
      const html = await response.text();

      const extract = (pid: string, id: string) => {
        const priceRegex = new RegExp(`class="[^"]*pid-${pid}-last[^"]*">([\\d,.]+)`, 'i');
        const changeRegex = new RegExp(`class="[^"]*pid-${pid}-pcp[^"]*">([+\\-]?[\\d,.]+)%`, 'i');
        const pMatch = html.match(priceRegex);
        const cMatch = html.match(changeRegex);

        if (pMatch && cMatch) {
          return { symbol: id, price: parseValue(pMatch[1]), change: parseValue(cMatch[1]), source: 'Investing.com' };
        }
        return null;
      };

      const results = [
        extract('20', 'NASDAQ'), extract('166', 'SP500'), extract('169', 'DOW'), extract('44336', 'VIX')
      ].filter(r => r !== null);

      if (results.length < 2) throw new Error("Investing Parsing Failed");
      return results;
    } catch (e) {
      console.error("Strategy D (Investing) Fail:", e);
      return null;
    }
  };

  try {
    // 1. Try CNBC Direct First (Fastest)
    let data = await fetchCNBC();

    // 2. Try RapidAPI CNBC (New High-Quality Backup)
    if (!data) {
        console.log("Switching to Strategy B: RapidAPI...");
        data = await fetchRapidCNBC();
    }

    // 3. Try TradingView
    if (!data) data = await fetchTradingView();

    // 4. Try Investing.com
    if (!data) data = await fetchInvestingCom();

    if (!data) return res.status(500).json({ error: "All Index Providers Failed" });

    return res.status(200).json(data);

  } catch (error: any) {
    return res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
}